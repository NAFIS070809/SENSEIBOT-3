const donasi = (pushname, prefix) => { 
	return `
┏━━━━━━━━━━━━━━━━━━━━
┃       𝗗𝗢𝗡𝗔𝗦𝗜  
┣━━━━━━━━━━━━━━━━━━━━
┣━⊱ *Donasi Untuk SENSEIBOT ❉⊰━━✿
┃  
┣━⊱ *PULSA*
┣⊱ _+6283159296996_
┗━━━━━━━━━━━━━━━━━━━━`
}

exports.donasi = donasi